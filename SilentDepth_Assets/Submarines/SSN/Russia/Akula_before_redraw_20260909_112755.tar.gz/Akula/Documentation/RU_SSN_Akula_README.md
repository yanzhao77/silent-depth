# RU_SSN_Akula

Status: VALIDATING

This version was rebuilt independently from the four user-supplied Project 971 reference boards. The previous template was abandoned for hull layout and tail proportions. UE4.27 import remains NOT VERIFIED.
